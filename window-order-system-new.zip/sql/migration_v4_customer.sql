USE window_order_system;

-- 1. 创建客户表
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(50) NOT NULL COMMENT '客户姓名',
  `phone` varchar(20) NOT NULL COMMENT '联系电话',
  `address` varchar(255) COMMENT '默认地址',
  `remark` varchar(500) COMMENT '备注（如：客户偏好、性格等）',
  `create_by` bigint COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint(1) DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户档案表';

-- 2. 订单表增加关联字段
ALTER TABLE `window_order` 
ADD COLUMN `customer_id` bigint COMMENT '关联客户ID' AFTER `customer_phone`;

-- 3. 索引
CREATE INDEX `idx_customer_id` ON `window_order` (`customer_id`);

-- 4. 数据迁移：从现有订单中提取客户信息
INSERT IGNORE INTO `customer` (`name`, `phone`, `address`, `create_time`)
SELECT customer_name, customer_phone, MAX(address), MIN(create_time)
FROM `window_order`
WHERE is_deleted = 0
GROUP BY customer_phone, customer_name;

-- 5. 数据关联：回填订单表中的 customer_id
UPDATE `window_order` o
JOIN `customer` c ON o.customer_phone = c.phone
SET o.customer_id = c.id
WHERE o.customer_id IS NULL;
