USE window_order_system;

DROP TABLE IF EXISTS `after_sales_order`;
CREATE TABLE `after_sales_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ticket_no` varchar(50) NOT NULL COMMENT '工单编号',
  `order_id` bigint NOT NULL COMMENT '关联原订单ID',
  `customer_name` varchar(50) COMMENT '客户姓名',
  `customer_phone` varchar(20) COMMENT '联系电话',
  `address` varchar(255) COMMENT '上门地址',
  `issue_description` text COMMENT '问题描述',
  `status` varchar(20) DEFAULT 'PENDING' COMMENT '状态：PENDING(待处理), ASSIGNED(已指派), PROCESSING(处理中), COMPLETED(已完成), CANCELLED(已取消)',
  `handler_id` bigint COMMENT '处理人ID（通常是安装师傅）',
  `appointment_time` datetime COMMENT '预约上门时间',
  `completion_time` datetime COMMENT '完成时间',
  `solution` text COMMENT '解决方案/维修结果',
  `fee` decimal(10, 2) DEFAULT 0.00 COMMENT '维修费用',
  `create_by` bigint COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint(1) DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ticket_no` (`ticket_no`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_handler_id` (`handler_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='售后工单表';
