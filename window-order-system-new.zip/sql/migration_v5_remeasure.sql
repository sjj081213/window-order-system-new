CREATE TABLE `remeasure_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `assignee_id` bigint NOT NULL COMMENT '指派师傅ID',
  `status` varchar(20) NOT NULL DEFAULT 'PENDING' COMMENT '状态：PENDING（待复尺）、COMPLETED（已完成）',
  `precise_width` double NULL COMMENT '精确宽度',
  `precise_height` double NULL COMMENT '精确高度',
  `sketch_url` varchar(255) NULL COMMENT '手绘图URL',
  `site_photos` text NULL COMMENT '现场图URL列表（JSON）',
  `remark` varchar(500) NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  INDEX `idx_order_id` (`order_id`),
  INDEX `idx_assignee_id` (`assignee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='复尺任务表';
