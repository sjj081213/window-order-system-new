USE window_order_system;

-- 1. 扩展订单表：增加产品参数和财务字段
ALTER TABLE `window_order` 
ADD COLUMN `window_type` varchar(50) COMMENT '窗型（如：推拉、平开、内倒）' AFTER `brand`,
ADD COLUMN `color` varchar(50) COMMENT '颜色' AFTER `window_type`,
ADD COLUMN `glass_spec` varchar(50) COMMENT '玻璃规格' AFTER `color`,
ADD COLUMN `paid_amount` decimal(10, 2) DEFAULT 0.00 COMMENT '已付金额' AFTER `price`,
ADD COLUMN `payment_status` varchar(20) DEFAULT 'UNPAID' COMMENT '支付状态：UNPAID（未支付）、PARTIAL（部分支付）、PAID（已付清）' AFTER `paid_amount`;

-- 2. 创建收款记录表
DROP TABLE IF EXISTS `order_payment`;
CREATE TABLE `order_payment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `amount` decimal(10, 2) NOT NULL COMMENT '收款金额',
  `pay_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收款时间',
  `pay_method` varchar(50) COMMENT '支付方式（微信、支付宝、现金、转账）',
  `remark` varchar(200) COMMENT '备注',
  `create_by` bigint COMMENT '操作人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_order_id`(`order_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '订单收款记录表' ROW_FORMAT = Dynamic;
