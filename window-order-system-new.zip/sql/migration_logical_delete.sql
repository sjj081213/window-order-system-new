-- 数据库迁移脚本：添加逻辑删除字段
-- 请在 MySQL 数据库中执行以下语句

USE window_order_system;

-- 1. 为 sys_user 表添加 is_deleted 字段
-- 如果字段已存在，此语句可能会报错，请忽略或先检查
SET @dbname = DATABASE();
SET @tablename = "sys_user";
SET @columnname = "is_deleted";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  "ALTER TABLE sys_user ADD COLUMN is_deleted tinyint(1) NULL DEFAULT 0 COMMENT '是否删除（0：否，1：是）';"
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 2. 为 brand 表添加 is_deleted 字段
SET @tablename = "brand";
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  "ALTER TABLE brand ADD COLUMN is_deleted tinyint(1) NULL DEFAULT 0 COMMENT '是否删除（0：否，1：是）';"
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 3. (可选) 更新现有数据的 is_deleted 默认为 0
UPDATE sys_user SET is_deleted = 0 WHERE is_deleted IS NULL;
UPDATE brand SET is_deleted = 0 WHERE is_deleted IS NULL;

-- 4. WindowOrder 表已经包含 is_deleted 字段，无需操作
